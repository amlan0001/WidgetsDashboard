﻿/// <reference path="CircularBar.html" />
/// <reference path="CircularBar.html" />
/// <reference path="CircularBar.html" />
"use strict";

angular.module("overallTeamReport", ['angular-svg-round-progress', 'gridster', 'ngStorage']);

angular.module("overallTeamReport").directive("overallTeamReport", function ($localStorage) {
    return {
        restrict: 'E',
        scope:{
            max: '@',
            current: '@'
        },
        templateUrl: "overallteamReport/overallTeamReport.html",
        link: function (scope, element, attrs) {
            scope.addNewWidget = function (widget)
            {
                var newWidget = angular.copy(widget);
               
                scope.widgets.push(newWidget);
            }

            scope.gridsterOpts = {
                columns: 24,
                margin: [20, 20],
                outerMargin: false,
                pushing: true,
                floating: true,
                swapping: false,
                //minSizeX: 4, // minimum column width of an item
               // maxSizeX: 4, // maximum column width of an item
               // minSizeY: 4, // minumum row height of an item
               // maxSizeY: 4, // maximum row height of an item
            };
            scope.widgetTitles = [];
            scope.widgetsDefinations = [
               
                {
                    title: "Team Analysis",
                            minSizeX: 4,
                            minSizeY: 4,
                            maxSizeX: 4,
                            maxSizeY: 4,
                            sizeX: 4,
                            sizeY: 4,
                            row: 0,
                            col: 4,
                            template: "<ps-circularbar></ps-circularbar>"
                      
                },
                {
                    title: "Milestone Completed",
                            minSizeX: 4,
                            minSizeY: 4,
                            maxSizeX: 4,
                            maxSizeY: 4,
                            sizeX: 4,
                            sizeY: 4,
                            row: 4,
                            col: 0,
                            template: "<ps-circularbar></ps-circularbar>"
                     
                },
                {
                    title: "Learning Compliance",
                   
                            sizeX: 8,
                            sizeY: 4,
                            row: 4,
                            col: 0,
                            template: "<ps-team-line-chart></ps-team-line-chart>"
                     
                },
                {
                    title: "Master Data",
                    
                            sizeX: 8,
                            sizeY: 4,
                            row: 4,
                            col: 0,
                            template: "<ps-circularbar></ps-circularbar>"
                      
                },
                {
                    title: "Today's Events",
                    
                            sizeX: 8,
                            sizeY: 4,
                            row: 4,
                            col: 0,
                            template: "<ps-circularbar></ps-circularbar>"
                      
                }
                



            ];
            
            scope.widgets = [];

            scope.$watch('widgets', function () {
                $localStorage.widgets = scope.widgets;
            }, true);
        }
    }
});

angular.module("overallTeamReport").directive("psCircularbar", function () {
    return {
        templateUrl: 'widgets/circularProgress/CircularBar.html'

    }
});

angular.module("overallTeamReport").directive("psTeamLineChart", function () {
    return {
        templateUrl: 'widgets/teamLineChart/teamLineChart.html',
        link: function (scope) {
            scope.data = [{
                id: 1,
                label: "Team 1",
                fillColor: "rgba(83, 26, 255,0)",
                strokeColor: "#0080FF",
                pointColor: "#0080FF",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "#0080FF",
                values: [10, 20, 30, 40, 50, 60, 70, 80, 40, 50, 60, 90]
            },
             {
                 id: 2,
                 label: "Team 2",
                 fillColor: "rgba(151,187,205,0)",
                 strokeColor: "rgba(151,187,205,1)",
                 pointColor: "rgba(151,187,205,1)",
                 pointStrokeColor: "#fff",
                 pointHighlightFill: "#fff",
                 pointHighlightStroke: "rgba(151,187,205,1)",
                 values: [11, 26, 12, 4, 59, 60, 78, 56, 78, 98, 76, 45]
             },
         {
             id: 3,
             label: "Team 3",
             fillColor: "rgba(17, 212, 180,0)",
             strokeColor: "rgb(17, 212, 180)",
             pointColor: "rgb(17, 212, 180)",
             pointStrokeColor: "#fff",
             pointHighlightFill: "#fff",
             pointHighlightStroke: "rgb(17, 212, 180)",
             values: [15, 28, 30, 89, 50, 64, 71, 56, 78, 90, 98, 97]
         },
         {
             id: 4,
             label: "Team 4",
             fillColor: "rgba(255, 77, 166,0)",
             strokeColor: "#ff4da6",
             pointColor: "#ff4da6",
             pointStrokeColor: "#fff",
             pointHighlightFill: "#fff",
             pointHighlightStroke: "#ff4da6",
             values: [13, 52, 23, 74, 85, 76, 90, 78, 80, 84, 90, 67]
         },
         {
             id: 5,
             label: "Team 5",
             fillColor: "rgba(255, 117, 26,0)",
             strokeColor: "#ff751a",
             pointColor: "#ff751a",
             pointStrokeColor: "#fff",
             pointHighlightFill: "#fff",
             pointHighlightStroke: "#ff751a",
             values: [21, 22, 63, 34, 75, 60, 100, 34, 12, 45, 68, 89]
         }
            ];

            var options = {
                responsive: true,
                maintainAspectRatio: true,
            }

            var filler = [];

            for (var i = 0; i < $scope.data.length; i++) {

                var fill = {
                    id: scope.data[i].id,
                    label: scope.data[i].label,
                    fillColor: scope.data[i].fillColor,
                    strokeColor: scope.data[i].strokeColor,
                    pointColor: scope.data[i].pointColor,
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: scope.data[i].pointHighlightStroke,
                    data: scope.data[i].values
                };

                filler.push(fill);
            }
            var vald = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            var d = 0;
            for (var i = 0; i < 12; i++) {
                d = 0;
                for (var j = 0; j < scope.data.length; j++) {

                    vald[i] = vald[i] + scope.data[j].values[i];

                }
                vald[i] = vald[i] / scope.data.length;

            }


            var avg = {
                id: scope.data.length + 1,
                label: "Average",
                fillColor: "rgba(220,220,220,0.4)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: vald
            };
            filler.push(avg);

            scope.filled = filler;
            var ctx = document.getElementById("c").getContext("2d");

            ctx.canvas.height = 100;
            ctx.canvas.width = 200;
            var data = {
                labels: ["January", "February", "March", "April", "May", "June", "July", "September", "October", "November", "December"],
                datasets: filler
            };


            var MyNewChart = new Chart(ctx).Line(data, options);


        }

    }
});