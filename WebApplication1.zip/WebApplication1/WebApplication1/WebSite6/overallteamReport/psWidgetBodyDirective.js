﻿
angular.module('overallTeamReport').directive('psWidgetBody',
    ['$compile',
        function ($compile)
        {
            return {
                templateUrl: 'overallteamReport/psWidgetBodyTemplate.html',
                link: function (scope, element, attrs)
                {
                    var newElement = angular.element(scope.item.template);
                    element.append(newElement);
                    $compile(newElement)(scope);
                }
            };
        }
    ]);