﻿
angular.module('overallTeamReport').directive('wwaTemperature',
    function ()
    {
        return {
            templateUrl: 'app/widgets/wwaTemperature/wwaTemperatureTemplate.html',
            
        };

    });